import React from 'react'
import styles from './Dashboard.module.scss'

export default function Dashboard() {
  return (
    <div className={styles.allContainer}>
      <h1>Bienvenue sur le dashboard de gestion de Marli Immobilier</h1>
    </div>
  )
}
